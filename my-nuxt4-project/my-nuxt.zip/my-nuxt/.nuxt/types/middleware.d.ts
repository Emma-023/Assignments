import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = string
declare module "/Users/emma/Library/CloudStorage/OneDrive-AssumptionUniversity/1-2023/WebAppDev/Assignment/4pages/my-nuxt3-project/my-nuxt/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}