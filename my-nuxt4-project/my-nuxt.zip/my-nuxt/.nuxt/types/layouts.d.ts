import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "default"
declare module "/Users/emma/Library/CloudStorage/OneDrive-AssumptionUniversity/1-2023/WebAppDev/Assignment/4pages/my-nuxt3-project/my-nuxt/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}