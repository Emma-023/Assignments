<template>
    <div>
        <h2>Moonbyul</h2>
        <div class="image-container">
            <img src="moonbyul.jpeg" alt="Image description">
        </div>
        <p>Moonbyul, whose real name is Moon Byul-yi, is a South Korean singer, rapper, and dancer. She is a member of the popular K-pop girl group Mamamoo, which debuted in 2014. Moonbyul serves as the main rapper and lead dancer in the group. Known for her powerful and charismatic stage presence, she has also gained recognition for her versatile talents, including acting and songwriting. Moonbyul is celebrated for her unique style, strong vocal and rapping skills, and contributions to Mamamoo's success as a talented performer and artist.</p>
    </div>
</template>

<script setup>

</script>

<style scoped>
    h2 {
        margin-bottom:  20px;
        font-size: 36px;
    }
    h5 {
        margin-bottom:  20px;
        font-size: 20px;
    }
    p {
        margin: 20px 0;
        text-align: justify;
    }

    .image-container {
        display: flex;
        justify-content: center;
    }

    .image-container img {
        max-width: 100%;
        height: auto;
    }

</style>