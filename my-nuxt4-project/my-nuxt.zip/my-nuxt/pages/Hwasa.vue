<template>
    <div>
        <h2>Hwasa</h2>
        <div class="image-container">
            <img src="hwasa.jpeg" alt="Image description">
        </div>
        <p>Hwasa, whose real name is Ahn Hye-jin, is a South Korean singer, songwriter, and member of the K-pop girl group MAMAMOO. She was born on July 23, 1995, in Jeonju, South Korea. Hwasa gained popularity for her powerful vocals, unique style, and charismatic stage presence. Apart from her work with MAMAMOO, she has also released solo music, showcasing her versatility as an artist. Hwasa is known for her confidence and individuality, making her a prominent figure in the K-pop industry.</p>

    </div>
</template>

<script setup>

</script>

<style scoped>
    h2 {
        margin-bottom:  20px;
        font-size: 36px;
    }
    h5 {
        margin-bottom:  20px;
        font-size: 20px;
    }
    p {
        margin: 20px 0;
        text-align: justify;
    }

    .image-container {
        display: flex;
        justify-content: center;
    }

    .image-container img {
        max-width: 100%;
        height: auto;
    }

</style>