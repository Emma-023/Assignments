<template>
    <div>
        <h2>Wheein</h2>
        <div class="image-container">
            <img src="wheein.jpg" alt="Image description">
        </div>
        <p>Wheein, whose full name is Jung Whee-in, is a South Korean singer, songwriter, and member of the popular K-pop girl group Mamamoo. Born on April 17, 1995, she is known for her powerful vocals, versatile singing style, and charming personality. Wheein has contributed to Mamamoo's success with her vocal talent and engaging stage presence. She has also released solo music and collaborated with other artists, showcasing her versatility as an artist. Wheein's talent and charisma have made her a beloved member of Mamamoo and a respected figure in the K-pop industry.</p>
    </div>
</template>

<script setup>

</script>

<style scoped>
    h2 {
        margin-bottom:  20px;
        font-size: 36px;
    }
    h5 {
        margin-bottom:  20px;
        font-size: 20px;
    }
    p {
        margin: 20px 0;
        text-align: justify;
    }

    .image-container {
        display: flex;
        justify-content: center;
    }

    .image-container img {
        max-width: 100%;
        height: auto;
    }

</style>