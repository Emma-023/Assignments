<template>
    <div>
        <h2>Assignment #1</h2>
        <h5>Mamamoo</h5>

        <div class="image-container">
            <img src="group.jpeg" alt="Image description">
        </div>

        <p>Mamamoo is a South Korean girl group formed in 2014. The group consists of four members: Solar, Moonbyul, Wheein, and Hwasa. Known for their powerful vocals, impressive harmonies, and dynamic performances, Mamamoo has gained a strong following in both South Korea and internationally. They are renowned for their versatile music style, which includes R&B, hip-hop, and jazz influences. With numerous hits and a reputation for their engaging stage presence, Mamamoo has become one of the leading and respected acts in the K-pop industry.</p>
    
    </div>
</template>

<script setup>

</script>

<style scoped>
    h2 {
        margin-bottom:  20px;
        font-size: 36px;
    }
    h5 {
        margin-bottom:  20px;
        font-size: 20px;
    }
    p {
        margin: 20px 0;
        text-align: justify;
    }

    .image-container {
        display: flex;
        justify-content: center;
    }

    .image-container img {
        max-width: 100%;
        height: auto;
    }

</style>