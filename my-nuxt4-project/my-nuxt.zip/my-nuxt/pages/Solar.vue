<template>
    <div>
        <h2>Solar</h2>
        <div class="image-container">
            <img src="solar.jpg" alt="Image description">
        </div>
        <p>Solar, whose real name is Kim Yong-sun, is a South Korean singer and the leader of the girl group Mamamoo. She was born on February 21, 1991. Solar is known for her powerful and versatile vocals, charming stage presence, and leadership qualities within the group. She has also released solo music and participated in various television shows, showcasing her talent and charisma as an entertainer.</p>
    </div>
</template>

<script setup>

</script>

<style scoped>
    h2 {
        margin-bottom:  20px;
        font-size: 36px;
    }
    h5 {
        margin-bottom:  20px;
        font-size: 20px;
    }
    p {
        margin: 20px 0;
        text-align: justify;
    }

    .image-container {
        display: flex;
        justify-content: center;
    }

    .image-container img {
        max-width: 100%;
        height: auto;
    }

</style>